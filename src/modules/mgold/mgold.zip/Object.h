#pragma once

#include "common/runtime.h"

namespace love { namespace graphics { class Mesh; } }

namespace love
{
namespace mgold
{

void MGOLD_setObjectFunc(lua_State *L);

// acesso nativo para o Render.cpp: Mesh do LOVE + quantos modelos visiveis (sem ler campos Lua).
// idx = tabela da malha (love.mgold.object.newMesh). Devolve false se nao for uma malha valida.
bool MGOLD_getMeshDrawInfo(lua_State *L, int idx, graphics::Mesh *&mesh, int &visibleCount);

}
}