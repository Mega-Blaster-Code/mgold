#pragma once

#include "common/runtime.h"
#include "common/Module.h"

#include "modules/graphics/Graphics.h"
#include "modules/graphics/Shader.h"
#include "modules/graphics/wrap_Shader.h"
#include "filesystem/Filesystem.h"
#include "filesystem/wrap_Filesystem.h"



namespace love
{
namespace mgold
{

void MGOLD_setShaderFunc(lua_State *L);

void MGOLD_pushDefaultShader(lua_State *L);

// Shader padrao + UniformInfo* ja resolvidas (nativo). O shader pertence ao registry do Lua
// (mesmo objeto de love.mgold.shader.default.get()); aqui so ha ponteiros, sem ownership.
struct DefaultUniforms
{
	graphics::Shader *shader = nullptr;
	unsigned generation = 0; // muda quando o shader e (re)criado -> Camera/Light remarcam tudo como sujo
	const graphics::Shader::UniformInfo *view = nullptr, *proj = nullptr, *canvas = nullptr;
	const graphics::Shader::UniformInfo *fogStart = nullptr, *fogEnd = nullptr, *fogColor = nullptr;
	const graphics::Shader::UniformInfo *globalLight = nullptr, *sunDir = nullptr;
};

// cria o shader na primeira chamada (precisa de janela). Erro Lua se falhar.
DefaultUniforms &MGOLD_defaultUniforms(lua_State *L);
inline graphics::Shader *MGOLD_defaultShader(lua_State *L){ return MGOLD_defaultUniforms(L).shader; }

// geracao atual sem criar nada (0 = ainda nao existe)
unsigned MGOLD_defaultGeneration();

// esquece o shader (novo lua_State / love.event.restart)
void MGOLD_resetDefaultShader();

} // mgold
} // love