#define _CRT_SECURE_NO_WARNINGS

/*
 * mgold_stdlib.c
 *
 *  - stdlib.malloc / mem   : zeroed raw memory, 0-based byte indexing, typed get/set,
 *                            peek/poke, copy/fill/find/cmp, hexdump, load/save
 *  - stdlib.struct / sizeof: C-like struct layout from a Lua table (size, align, offsets)
 *  - views / records       : typed arrays and struct arrays over a mem, 0-based
 *  - stdlib.str            : string helpers
 *  - stdlib.bit            : bit helpers (rol/ror/bswap/extract/...)
 *
 * Build: Lua 5.1.  e.g.  cc -O2 -shared -fPIC mgold_stdlib.c -o stdlib.so
 */
#include "Stdlib.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lauxlib.h"
#include "lua.h"
 /* Lua 5.1 compatibility helpers for code originally written for Lua 5.4. */

static int mg_absindex(lua_State *L, int idx)
{
	if (idx > 0 || idx <= LUA_REGISTRYINDEX)
		return idx;
	return lua_gettop(L) + idx + 1;
}

static void mg_setmetatable(lua_State *L, const char *name)
{
	luaL_getmetatable(L, name);
	lua_setmetatable(L, -2);
}

static void *mg_testudata(lua_State *L, int idx, const char *name)
{
	void *p;
	idx = mg_absindex(L, idx);
	if (!lua_isuserdata(L, idx))
		return NULL;
	if (!lua_getmetatable(L, idx))
		return NULL;
	luaL_getmetatable(L, name);
	if (!lua_rawequal(L, -1, -2))
	{
		lua_pop(L, 2);
		return NULL;
	}
	lua_pop(L, 2);
	p = lua_touserdata(L, idx);
	return p;
}

static lua_Integer mg_tointegerx(lua_State *L, int idx, int *ok)
{
	lua_Number n;
	lua_Integer i;

	if (!lua_isnumber(L, idx))
	{
		*ok = 0;
		return 0;
	}

	n = lua_tonumber(L, idx);
	i = (lua_Integer)n;
	*ok = ((lua_Number)i == n);
	return i;
}

/*
 * Lua 5.1 userdata has one environment table instead of multiple uservalues.
 * We use that environment as a small numbered anchor table.
 */
static void mg_setiuservalue(lua_State *L, int idx, int n)
{
	int value, env;

	idx = mg_absindex(L, idx);
	value = lua_gettop(L);

	lua_getfenv(L, idx);
	if (lua_type(L, -1) != LUA_TTABLE)
	{
		lua_pop(L, 1);
		lua_newtable(L);
		lua_pushvalue(L, idx);
		lua_setfenv(L, -2);
	}

	env = lua_gettop(L);
	lua_pushvalue(L, value);
	lua_rawseti(L, env, n);

	lua_pop(L, 1); /* environment */
	lua_pop(L, 1); /* original value */
}

static void mg_getiuservalue(lua_State *L, int idx, int n)
{
	idx = mg_absindex(L, idx);
	lua_getfenv(L, idx);
	if (lua_type(L, -1) != LUA_TTABLE)
	{
		lua_pop(L, 1);
		lua_pushnil(L);
		return;
	}
	lua_rawgeti(L, -1, n);
	lua_remove(L, -2); /* remove environment, leave value */
}

static int mg_typeerror(lua_State *L, int idx, const char *tname)
{
	const char *msg = lua_pushfstring(L, "%s expected, got %s",
									  tname, luaL_typename(L, idx));
	return luaL_argerror(L, idx, msg);
}

static void mg_setfuncs(lua_State *L, const luaL_Reg *l, int nup)
{
	while (l->name)
	{
		lua_pushstring(L, l->name);
		lua_pushcclosure(L, l->func, nup);
		lua_settable(L, -3);
		++l;
	}
}

static void mg_newlib(lua_State *L, const luaL_Reg *l)
{
	lua_newtable(L);
	mg_setfuncs(L, l, 0);
}

#define lua_absindex       mg_absindex
#define luaL_setmetatable  mg_setmetatable
#define luaL_testudata     mg_testudata
#define luaL_typeerror     mg_typeerror
#define lua_tointegerx     mg_tointegerx
#define lua_rawlen         lua_objlen
#define lua_newuserdatauv(L,size,nuv) lua_newuserdata(L,size)
#define lua_getiuservalue   mg_getiuservalue
#define lua_setiuservalue   mg_setiuservalue
#define luaL_setfuncs       mg_setfuncs
#define lua_isinteger(L,idx) 0



namespace love
{
namespace mgold
{

#define MG_MAX_ALLOC ((size_t)1 << 30) /* 1 GiB hard cap for a single block */
#define MG_MAX_STRUCT ((uint64_t)1 << 28)
#define MG_NAME_MAX 32

#define STRUCT_MT "mgold.struct"
#define VIEW_MT "mgold.view"

/* ======================================================================= */
/*  Small helpers                                                          */
/* ======================================================================= */

static int host_is_le(void)
{
	const uint16_t x = 1;
	return *(const uint8_t *)&x == 1;
}

static void rev_bytes(uint8_t *b, size_t n)
{
	for (size_t i = 0, j = n; i < j / 2; i++)
	{
		uint8_t t = b[i];
		b[i] = b[j - 1 - i];
		b[j - 1 - i] = t;
	}
}

/* Convert a Lua value to an integer; floats are truncated, booleans become 0/1. */
static lua_Integer arg_int(lua_State *L, int idx)
{
	switch (lua_type(L, idx))
	{
	case LUA_TBOOLEAN:
		return lua_toboolean(L, idx);
	case LUA_TNUMBER: {
		if (lua_isinteger(L, idx)) return lua_tointeger(L, idx);
		lua_Number d = lua_tonumber(L, idx);
		if (!(d > -9.2e18 && d < 9.2e18)) luaL_error(L, "number out of range");
		return (lua_Integer)d;
	}
	default:
		return luaL_checkinteger(L, idx); /* raises a proper type error */
	}
}

static size_t arg_off(lua_State *L, int idx, size_t def)
{
	if (lua_isnoneornil(L, idx)) return def;
	lua_Integer v = luaL_checkinteger(L, idx);
	if (v < 0) luaL_argerror(L, idx, "negative offset/length");
	return (size_t)v;
}

static void check_range(lua_State *L, const mg_mem *m, size_t off, size_t len)
{
	if (off > m->size || len > m->size - off)
		luaL_error(L, "memory range out of bounds (offset %I, length %I, size %I)",
				   (lua_Integer)off, (lua_Integer)len, (lua_Integer)m->size);
}

/* ======================================================================= */
/*  Primitive types                                                        */
/* ======================================================================= */

typedef enum { P_I8, P_U8, P_I16, P_U16, P_I32, P_U32, P_I64, P_U64, P_F32, P_F64, P_BOOL, P_COUNT } prim_t;

struct mg_type;
typedef struct mg_field
{
	char name[MG_NAME_MAX];
	const struct mg_type *type;
	uint32_t offset;
	uint32_t count;  /* 1 for scalars */
	int is_array;
} mg_field;

typedef struct mg_type
{
	int is_struct;
	int prim;
	uint32_t size, align;
	int nfields;
	mg_field *fields;
} mg_type;

static const mg_type PRIM_TYPES[P_COUNT] = {
	{ 0, P_I8, 1, 1, 0, NULL },{ 0, P_U8, 1, 1, 0, NULL },{ 0, P_I16, 2, 2, 0, NULL },
	{ 0, P_U16, 2, 2, 0, NULL },{ 0, P_I32, 4, 4, 0, NULL },{ 0, P_U32, 4, 4, 0, NULL },
	{ 0, P_I64, 8, 8, 0, NULL },{ 0, P_U64, 8, 8, 0, NULL },{ 0, P_F32, 4, 4, 0, NULL },
	{ 0, P_F64, 8, 8, 0, NULL },{ 0, P_BOOL, 1, 1, 0, NULL },
};

static const char *const PRIM_NAMES[P_COUNT] = { "i8", "u8", "i16", "u16", "i32", "u32",
												"i64", "u64", "f32", "f64", "bool" };

static const struct
{
	const char *name;
	int prim;
} ALIASES[] = {
	{ "i8", P_I8 },{ "int8", P_I8 },{ "char", P_I8 },{ "int8_t", P_I8 },
	{ "u8", P_U8 },{ "uint8", P_U8 },{ "byte", P_U8 },{ "uint8_t", P_U8 },
	{ "i16", P_I16 },{ "int16", P_I16 },{ "short", P_I16 },{ "int16_t", P_I16 },
	{ "u16", P_U16 },{ "uint16", P_U16 },{ "ushort", P_U16 },{ "word", P_U16 },{ "uint16_t", P_U16 },
	{ "i32", P_I32 },{ "int32", P_I32 },{ "int", P_I32 },{ "int32_t", P_I32 },
	{ "u32", P_U32 },{ "uint32", P_U32 },{ "uint", P_U32 },{ "dword", P_U32 },{ "uint32_t", P_U32 },
	{ "i64", P_I64 },{ "int64", P_I64 },{ "int64_t", P_I64 },
	{ "u64", P_U64 },{ "uint64", P_U64 },{ "uint64_t", P_U64 },
	{ "f32", P_F32 },{ "float", P_F32 },{ "f64", P_F64 },{ "double", P_F64 },{ "bool", P_BOOL },
	{ NULL, 0 } };

static int find_prim(const char *s, size_t len)
{
	for (int i = 0; ALIASES[i].name; i++)
		if (strlen(ALIASES[i].name) == len && memcmp(ALIASES[i].name, s, len) == 0) return ALIASES[i].prim;
	return -1;
}

/* "u16", "u16be", "u16le" -> prim index; *swap tells if bytes must be reversed vs host order */
static int check_prim_name(lua_State *L, int idx, int *swap)
{
	size_t n;
	const char *s = luaL_checklstring(L, idx, &n);
	int endian = 0; /* 0 host, 1 big, 2 little */
	int p = find_prim(s, n);
	if (p < 0 && n > 2)
	{
		if (s[n - 2] == 'b' && s[n - 1] == 'e') endian = 1;
		else if (s[n - 2] == 'l' && s[n - 1] == 'e') endian = 2;
		if (endian) p = find_prim(s, n - 2);
	}
	if (p < 0) luaL_argerror(L, idx, lua_pushfstring(L, "unknown type '%s'", s));
	int le = host_is_le();
	*swap = (endian == 1 && le) || (endian == 2 && !le);
	return p;
}

static void push_prim(lua_State *L, int prim, const uint8_t *p, int swap)
{
	uint8_t b[8];
	size_t sz = PRIM_TYPES[prim].size;
	memcpy(b, p, sz);
	if (swap) rev_bytes(b, sz);
	switch (prim)
	{
	case P_I8: lua_pushinteger(L, (int8_t)b[0]); break;
	case P_U8: lua_pushinteger(L, b[0]); break;
	case P_I16: { int16_t v; memcpy(&v, b, 2); lua_pushinteger(L, v); break; }
	case P_U16: { uint16_t v; memcpy(&v, b, 2); lua_pushinteger(L, v); break; }
	case P_I32: { int32_t v; memcpy(&v, b, 4); lua_pushinteger(L, v); break; }
	case P_U32: { uint32_t v; memcpy(&v, b, 4); lua_pushinteger(L, v); break; }
	case P_I64: { int64_t v; memcpy(&v, b, 8); lua_pushinteger(L, (lua_Integer)v); break; }
	case P_U64: { uint64_t v; memcpy(&v, b, 8); lua_pushinteger(L, (lua_Integer)v); break; } /* wraps if > 2^63 */
	case P_F32: { float v; memcpy(&v, b, 4); lua_pushnumber(L, v); break; }
	case P_F64: { double v; memcpy(&v, b, 8); lua_pushnumber(L, v); break; }
	case P_BOOL: lua_pushboolean(L, b[0] != 0); break;
	}
}

static void store_prim(lua_State *L, int prim, uint8_t *p, int swap, int idx)
{
	uint8_t b[8];
	switch (prim)
	{
	case P_I8: case P_U8: b[0] = (uint8_t)arg_int(L, idx); break;
	case P_I16: case P_U16: { uint16_t v = (uint16_t)arg_int(L, idx); memcpy(b, &v, 2); break; }
	case P_I32: case P_U32: { uint32_t v = (uint32_t)arg_int(L, idx); memcpy(b, &v, 4); break; }
	case P_I64: case P_U64: { uint64_t v = (uint64_t)arg_int(L, idx); memcpy(b, &v, 8); break; }
	case P_F32: { float v = (float)luaL_checknumber(L, idx); memcpy(b, &v, 4); break; }
	case P_F64: { double v = luaL_checknumber(L, idx); memcpy(b, &v, 8); break; }
	case P_BOOL:
		b[0] = (lua_type(L, idx) == LUA_TBOOLEAN) ? (uint8_t)lua_toboolean(L, idx) : (arg_int(L, idx) != 0);
		break;
	default: b[0] = 0;
	}
	size_t sz = PRIM_TYPES[prim].size;
	if (swap) rev_bytes(b, sz);
	memcpy(p, b, sz);
}

/* ======================================================================= */
/*  mem                                                                    */
/* ======================================================================= */

mg_mem *mgold_tomem(lua_State *L, int idx) { return (mg_mem *)luaL_testudata(L, idx, MG_MEM_MT); }

mg_mem *mgold_checkmem(lua_State *L, int idx)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, idx, MG_MEM_MT);
	if (!m->data) luaL_error(L, "use of freed memory");
	return m;
}

mg_mem *mgold_newmem(lua_State *L, size_t size)
{
	if (size < 1 || size > MG_MAX_ALLOC) luaL_error(L, "invalid allocation size %I", (lua_Integer)size);
	mg_mem *m = (mg_mem *)lua_newuserdatauv(L, sizeof(mg_mem), 0);
	m->data = NULL;
	m->size = 0;
	luaL_setmetatable(L, MG_MEM_MT);
	m->data = (uint8_t *)calloc(1, size);
	if (!m->data) luaL_error(L, "out of memory (%I bytes)", (lua_Integer)size);
	m->size = size;
	return m;
}

static int mem_gc(lua_State *L)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, 1, MG_MEM_MT);
	free(m->data);
	m->data = NULL;
	m->size = 0;
	return 0;
}

/* mem[i] (byte, 0-based) or method lookup */
static int mem_index(lua_State *L)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, 1, MG_MEM_MT);
	if (lua_type(L, 2) == LUA_TNUMBER)
	{
		int ok;
		lua_Integer i = lua_tointegerx(L, 2, &ok);
		if (!ok) return luaL_error(L, "mem index must be an integer");
		if (!m->data) return luaL_error(L, "use of freed memory");
		if (i < 0 || (size_t)i >= m->size)
			return luaL_error(L, "mem index %I out of range (size %I)", i, (lua_Integer)m->size);
		lua_pushinteger(L, m->data[i]);
		return 1;
	}
	lua_pushvalue(L, 2);
	lua_rawget(L, lua_upvalueindex(1));
	return 1;
}

static int mem_newindex(lua_State *L)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, 1, MG_MEM_MT);
	int ok;
	lua_Integer i = lua_tointegerx(L, 2, &ok);
	if (!ok) return luaL_error(L, "mem index must be an integer");
	if (!m->data) return luaL_error(L, "use of freed memory");
	if (i < 0 || (size_t)i >= m->size)
		return luaL_error(L, "mem index %I out of range (size %I)", i, (lua_Integer)m->size);
	m->data[i] = (uint8_t)arg_int(L, 3);
	return 0;
}

static int mem_len(lua_State *L)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, 1, MG_MEM_MT);
	lua_pushinteger(L, (lua_Integer)m->size);
	return 1;
}

static int mem_tostring(lua_State *L)
{
	mg_mem *m = (mg_mem *)luaL_checkudata(L, 1, MG_MEM_MT);
	if (!m->data) lua_pushstring(L, "mem<freed>");
	else lua_pushfstring(L, "mem<%p, %I bytes>", (void *)m->data, (lua_Integer)m->size);
	return 1;
}

static int m_free(lua_State *L) { return mem_gc(L); }

static int m_size(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	lua_pushinteger(L, (lua_Integer)m->size);
	return 1;
}

static int m_ptr(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	lua_pushinteger(L, (lua_Integer)(intptr_t)m->data);
	return 1;
}

/* mem:fill(value [, offset=0 [, length=rest]]) */
static int m_fill(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	int v = (int)(arg_int(L, 2) & 0xFF);
	size_t off = arg_off(L, 3, 0);
	if (off > m->size) luaL_argerror(L, 3, "offset out of bounds");
	size_t len = arg_off(L, 4, m->size - off);
	check_range(L, m, off, len);
	memset(m->data + off, v, len);
	lua_settop(L, 1);
	return 1;
}

/* mem:copy(dstOff, src(mem|string) [, srcOff=0 [, len=rest]])  -- memmove semantics */
static int m_copy(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t doff = arg_off(L, 2, 0);
	const uint8_t *src;
	size_t ssize;
	mg_mem *sm = mgold_tomem(L, 3);
	if (sm)
	{
		if (!sm->data) return luaL_error(L, "use of freed memory");
		src = sm->data;
		ssize = sm->size;
	}
	else
	{
		src = (const uint8_t *)luaL_checklstring(L, 3, &ssize);
	}
	size_t soff = arg_off(L, 4, 0);
	if (soff > ssize) luaL_argerror(L, 4, "source offset out of bounds");
	size_t len = arg_off(L, 5, ssize - soff);
	if (len > ssize - soff) luaL_argerror(L, 5, "source range out of bounds");
	check_range(L, m, doff, len);
	memmove(m->data + doff, src + soff, len);
	lua_pushinteger(L, (lua_Integer)len);
	return 1;
}

/* mem:get(type, offset)  /  mem:set(type, offset, value) */
static int m_get(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	int swap;
	int p = check_prim_name(L, 2, &swap);
	size_t off = arg_off(L, 3, 0);
	check_range(L, m, off, PRIM_TYPES[p].size);
	push_prim(L, p, m->data + off, swap);
	return 1;
}

static int m_set(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	int swap;
	int p = check_prim_name(L, 2, &swap);
	size_t off = arg_off(L, 3, 0);
	check_range(L, m, off, PRIM_TYPES[p].size);
	store_prim(L, p, m->data + off, swap, 4);
	lua_settop(L, 1);
	return 1;
}

static int m_peek(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t a = arg_off(L, 2, 0);
	check_range(L, m, a, 1);
	lua_pushinteger(L, m->data[a]);
	return 1;
}

static int m_poke(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t a = arg_off(L, 2, 0);
	check_range(L, m, a, 1);
	m->data[a] = (uint8_t)arg_int(L, 3);
	return 0;
}

/* 16-bit little endian (6502 style) */
static int m_peek16(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t a = arg_off(L, 2, 0);
	check_range(L, m, a, 2);
	lua_pushinteger(L, m->data[a] | (m->data[a + 1] << 8));
	return 1;
}

static int m_poke16(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t a = arg_off(L, 2, 0);
	check_range(L, m, a, 2);
	lua_Integer v = arg_int(L, 3);
	m->data[a] = (uint8_t)(v & 0xFF);
	m->data[a + 1] = (uint8_t)((v >> 8) & 0xFF);
	return 0;
}

/* mem:getstr(offset, length) -> binary-safe Lua string */
static int m_getstr(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	if (off > m->size) luaL_argerror(L, 2, "offset out of bounds");
	size_t len = arg_off(L, 3, m->size - off);
	check_range(L, m, off, len);
	lua_pushlstring(L, (const char *)m->data + off, len);
	return 1;
}

/* mem:setstr(offset, str) -> bytes written */
static int m_setstr(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	size_t len;
	const char *s = luaL_checklstring(L, 3, &len);
	check_range(L, m, off, len);
	memcpy(m->data + off, s, len);
	lua_pushinteger(L, (lua_Integer)len);
	return 1;
}

/* mem:cstr(offset [, max]) -> string until first NUL */
static int m_cstr(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	if (off > m->size) luaL_argerror(L, 2, "offset out of bounds");
	size_t max = arg_off(L, 3, m->size - off);
	if (max > m->size - off) max = m->size - off;
	const uint8_t *p = m->data + off;
	const uint8_t *z = (const uint8_t *)memchr(p, 0, max);
	lua_pushlstring(L, (const char *)p, z ? (size_t)(z - p) : max);
	return 1;
}

static const char *mem_find_bytes(const char *h, size_t hl, const char *n, size_t nl)
{
	if (nl == 0) return h;
	if (nl > hl) return NULL;
	const char *end = h + (hl - nl) + 1;
	while (h < end)
	{
		h = (const char *)memchr(h, n[0], (size_t)(end - h));
		if (!h) return NULL;
		if (memcmp(h, n, nl) == 0) return h;
		h++;
	}
	return NULL;
}

/* mem:find(needle(string|byte) [, start=0]) -> offset | nil */
static int m_find(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	char one;
	const char *n;
	size_t nl;
	if (lua_type(L, 2) == LUA_TNUMBER)
	{
		one = (char)arg_int(L, 2);
		n = &one;
		nl = 1;
	}
	else
	{
		n = luaL_checklstring(L, 2, &nl);
	}
	size_t start = arg_off(L, 3, 0);
	if (start > m->size) return 0;
	const char *r = mem_find_bytes((const char *)m->data + start, m->size - start, n, nl);
	if (!r)
	{
		lua_pushnil(L);
		return 1;
	}
	lua_pushinteger(L, (lua_Integer)(r - (const char *)m->data));
	return 1;
}

/* mem:cmp(off, other(mem|string), otherOff, len) -> -1/0/1 */
static int m_cmp(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	const uint8_t *o;
	size_t osz;
	mg_mem *om = mgold_tomem(L, 3);
	if (om)
	{
		if (!om->data) return luaL_error(L, "use of freed memory");
		o = om->data;
		osz = om->size;
	}
	else
	{
		o = (const uint8_t *)luaL_checklstring(L, 3, &osz);
	}
	size_t ooff = arg_off(L, 4, 0);
	if (ooff > osz) luaL_argerror(L, 4, "offset out of bounds");
	size_t len = arg_off(L, 5, osz - ooff);
	check_range(L, m, off, len);
	if (len > osz - ooff) luaL_argerror(L, 5, "range out of bounds");
	int r = memcmp(m->data + off, o + ooff, len);
	lua_pushinteger(L, r < 0 ? -1 : (r > 0 ? 1 : 0));
	return 1;
}

static int m_resize(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	lua_Integer n = luaL_checkinteger(L, 2);
	if (n < 1 || (size_t)n > MG_MAX_ALLOC) return luaL_argerror(L, 2, "invalid size");
	uint8_t *nd = (uint8_t *)realloc(m->data, (size_t)n);
	if (!nd) return luaL_error(L, "out of memory");
	if ((size_t)n > m->size) memset(nd + m->size, 0, (size_t)n - m->size);
	m->data = nd;
	m->size = (size_t)n;
	lua_settop(L, 1);
	return 1;
}

/* mem:sub(offset, length) -> new mem (copy) */
static int m_sub(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	if (off > m->size) luaL_argerror(L, 2, "offset out of bounds");
	size_t len = arg_off(L, 3, m->size - off);
	check_range(L, m, off, len);
	mg_mem *n = mgold_newmem(L, len ? len : 1);
	memcpy(n->data, m->data + off, len);
	if (len == 0) n->size = 1;
	return 1;
}

/* mem:hexdump([offset=0 [, length=rest [, width=16 [, baseAddr=offset]]]]) */
static int m_hexdump(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	if (off > m->size) luaL_argerror(L, 2, "offset out of bounds");
	size_t len = arg_off(L, 3, m->size - off);
	check_range(L, m, off, len);
	size_t width = arg_off(L, 4, 16);
	if (width < 1 || width > 64) luaL_argerror(L, 4, "width must be 1..64");
	size_t base = arg_off(L, 5, off);
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	char tmp[16];
	for (size_t i = 0; i < len; i += width)
	{
		int n = snprintf(tmp, sizeof tmp, "%08zX  ", base + i);
		luaL_addlstring(&b, tmp, (size_t)n);
		for (size_t j = 0; j < width; j++)
		{
			if (i + j < len)
			{
				n = snprintf(tmp, sizeof tmp, "%02X ", m->data[off + i + j]);
				luaL_addlstring(&b, tmp, (size_t)n);
			}
			else
			{
				luaL_addstring(&b, "   ");
			}
		}
		luaL_addstring(&b, " |");
		for (size_t j = 0; j < width && i + j < len; j++)
		{
			uint8_t c = m->data[off + i + j];
			luaL_addchar(&b, (c >= 32 && c < 127) ? (char)c : '.');
		}
		luaL_addstring(&b, "|\n");
	}
	luaL_pushresult(&b);
	return 1;
}

/* ---- CRC32 / Adler32 / FNV ---- */
static uint32_t crc_tab[256];
static int crc_ready = 0;

static void crc_init(void)
{
	if (crc_ready) return;
	for (uint32_t i = 0; i < 256; i++)
	{
		uint32_t c = i;
		for (int k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
		crc_tab[i] = c;
	}
	crc_ready = 1;
}

static uint32_t crc32_run(uint32_t prev, const uint8_t *p, size_t n)
{
	uint32_t c = ~prev;
	while (n--) c = crc_tab[(c ^ *p++) & 0xFF] ^ (c >> 8);
	return ~c;
}

static int m_crc32(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	if (off > m->size) luaL_argerror(L, 2, "offset out of bounds");
	size_t len = arg_off(L, 3, m->size - off);
	check_range(L, m, off, len);
	lua_pushinteger(L, crc32_run((uint32_t)luaL_optinteger(L, 4, 0), m->data + off, len));
	return 1;
}

/* mem:save(path [, offset, length]) */
static int m_save(lua_State *L)
{
	mg_mem *m = mgold_checkmem(L, 1);
	const char *path = luaL_checkstring(L, 2);
	size_t off = arg_off(L, 3, 0);
	if (off > m->size) luaL_argerror(L, 3, "offset out of bounds");
	size_t len = arg_off(L, 4, m->size - off);
	check_range(L, m, off, len);
	FILE *f = fopen(path, "wb");
	if (!f) return luaL_fileresult(L, 0, path);
	size_t w = fwrite(m->data + off, 1, len, f);
	int cerr = fclose(f);
	if (w != len || cerr != 0) return luaL_fileresult(L, 0, path);
	lua_pushboolean(L, 1);
	return 1;
}

/* stdlib.readfile(path) -> mem | nil, err */
static int l_readfile(lua_State *L)
{
	const char *path = luaL_checkstring(L, 1);
	FILE *f = fopen(path, "rb");
	if (!f) return luaL_fileresult(L, 0, path);
	if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return luaL_fileresult(L, 0, path); }
	long sz = ftell(f);
	if (sz < 0 || fseek(f, 0, SEEK_SET) != 0) { fclose(f); return luaL_fileresult(L, 0, path); }
	if ((size_t)sz > MG_MAX_ALLOC) { fclose(f); lua_pushnil(L); lua_pushstring(L, "file too large"); return 2; }
	mg_mem *m = mgold_newmem(L, sz > 0 ? (size_t)sz : 1);
	size_t r = sz > 0 ? fread(m->data, 1, (size_t)sz, f) : 0;
	fclose(f);
	if (r != (size_t)sz) { lua_pushnil(L); lua_pushstring(L, "read error"); return 2; }
	if (sz == 0) m->size = 1;
	return 1;
}

static int l_malloc(lua_State *L)
{
	lua_Integer n = luaL_checkinteger(L, 1);
	if (n < 1 || (uint64_t)n > MG_MAX_ALLOC) return luaL_argerror(L, 1, "invalid size");
	mgold_newmem(L, (size_t)n);
	return 1;
}

static int l_free(lua_State *L)
{
	luaL_checkudata(L, 1, MG_MEM_MT);
	return mem_gc(L);
}

/* stdlib.tomem(str) -> mem with the string bytes */
static int l_tomem(lua_State *L)
{
	size_t n;
	const char *s = luaL_checklstring(L, 1, &n);
	mg_mem *m = mgold_newmem(L, n ? n : 1);
	memcpy(m->data, s, n);
	return 1;
}

/* functional forms */
static int l_memcpy(lua_State *L)
{ /* memcpy(dst, dstOff, src, srcOff, len) */
	mg_mem *d = mgold_checkmem(L, 1);
	size_t doff = arg_off(L, 2, 0);
	const uint8_t *src;
	size_t ssz;
	mg_mem *sm = mgold_tomem(L, 3);
	if (sm)
	{
		if (!sm->data) return luaL_error(L, "use of freed memory");
		src = sm->data;
		ssz = sm->size;
	}
	else
	{
		src = (const uint8_t *)luaL_checklstring(L, 3, &ssz);
	}
	size_t soff = arg_off(L, 4, 0);
	size_t len = arg_off(L, 5, 0);
	if (soff > ssz || len > ssz - soff) return luaL_error(L, "source range out of bounds");
	check_range(L, d, doff, len);
	memmove(d->data + doff, src + soff, len);
	return 0;
}

static int l_memset(lua_State *L)
{ /* memset(mem, off, value, len) */
	mg_mem *m = mgold_checkmem(L, 1);
	size_t off = arg_off(L, 2, 0);
	int v = (int)(arg_int(L, 3) & 0xFF);
	size_t len = arg_off(L, 4, 0);
	check_range(L, m, off, len);
	memset(m->data + off, v, len);
	return 0;
}

/* ======================================================================= */
/*  struct                                                                 */
/* ======================================================================= */

typedef struct mg_struct
{
	mg_type t;
} mg_struct;

static int struct_gc(lua_State *L)
{
	mg_struct *s = (mg_struct *)luaL_checkudata(L, 1, STRUCT_MT);
	free(s->t.fields);
	s->t.fields = NULL;
	s->t.nfields = 0;
	return 0;
}

static uint64_t align_up(uint64_t v, uint64_t a) { return (v + a - 1) / a * a; }

/* Split "name[16]" -> base "name" + count. Returns 0 on syntax error. */
static int split_array(const char *s, size_t len, char *base, size_t cap, uint32_t *count, int *is_array)
{
	*count = 1;
	*is_array = 0;
	const char *br = (const char *)memchr(s, '[', len);
	size_t blen = br ? (size_t)(br - s) : len;
	if (blen == 0 || blen >= cap) return 0;
	memcpy(base, s, blen);
	base[blen] = 0;
	if (br)
	{
		const char *p = br + 1, *end = s + len;
		uint64_t n = 0;
		int digits = 0;
		while (p < end && *p >= '0' && *p <= '9')
		{
			n = n * 10 + (uint64_t)(*p - '0');
			if (n > 0xFFFFFF) return 0;
			p++;
			digits++;
		}
		if (!digits || n == 0 || p >= end || *p != ']' || p + 1 != end) return 0;
		*count = (uint32_t)n;
		*is_array = 1;
	}
	return 1;
}

static const mg_field *find_field(const mg_type *t, const char *name, size_t len)
{
	for (int i = 0; i < t->nfields; i++)
		if (strlen(t->fields[i].name) == len && memcmp(t->fields[i].name, name, len) == 0) return &t->fields[i];
	return NULL;
}

/* Resolve a type value at idx (string or struct userdata) */
static const mg_type *resolve_type(lua_State *L, int idx, int sidx, uint32_t *count, int *is_array)
{
	idx = lua_absindex(L, idx);
	mg_struct *ns = (mg_struct *)luaL_testudata(L, idx, STRUCT_MT);
	if (ns)
	{
		lua_getiuservalue(L, sidx, 1);
		lua_pushvalue(L, idx);
		lua_rawseti(L, -2, (lua_Integer)lua_rawlen(L, -2) + 1);
		lua_pop(L, 1);
		return &ns->t;
	}
	size_t n;
	const char *s = luaL_checklstring(L, idx, &n);
	char base[64];
	uint32_t c;
	int arr;
	if (!split_array(s, n, base, sizeof base, &c, &arr)) luaL_error(L, "bad type syntax '%s'", s);
	int p = find_prim(base, strlen(base));
	if (p < 0) luaL_error(L, "unknown type '%s'", base);
	if (arr)
	{
		*count = c;
		*is_array = 1;
	}
	return &PRIM_TYPES[p];
}

static void parse_entry(lua_State *L, int e, int sidx, mg_field *f, const mg_field *prev, int nprev)
{
	char nbuf[MG_NAME_MAX + 8];
	uint32_t count = 1;
	int is_array = 0;
	const mg_type *type;
	int base = lua_gettop(L);

	if (lua_type(L, e) == LUA_TSTRING)
	{
		size_t sl;
		const char *s = lua_tolstring(L, e, &sl);
		const char *p = s;
		while (isspace((unsigned char)*p)) p++;
		const char *t0 = p;
		while (*p && !isspace((unsigned char)*p)) p++;
		size_t tl = (size_t)(p - t0);
		while (isspace((unsigned char)*p)) p++;
		const char *n0 = p;
		while (*p && !isspace((unsigned char)*p)) p++;
		size_t nl = (size_t)(p - n0);
		while (isspace((unsigned char)*p)) p++;
		if (tl == 0 || nl == 0 || *p) luaL_error(L, "bad field '%s' (expected \"type name\" or \"type name[count]\")", s);
		lua_pushlstring(L, t0, tl);
		type = resolve_type(L, -1, sidx, &count, &is_array);
		uint32_t nc;
		int na;
		if (!split_array(n0, nl, nbuf, sizeof nbuf, &nc, &na)) luaL_error(L, "bad field name in '%s'", s);
		if (na)
		{
			if (is_array) luaL_error(L, "array count given twice in '%s'", s);
			count = nc;
			is_array = 1;
		}
	}
	else if (lua_type(L, e) == LUA_TTABLE)
	{
		lua_rawgeti(L, e, 1);
		lua_rawgeti(L, e, 2);
		lua_rawgeti(L, e, 3);
		int ni = base + 1, ti = base + 2, ci = base + 3;
		if (lua_type(L, ni) != LUA_TSTRING) luaL_error(L, "field entry: [1] must be the field name");
		if (lua_isnil(L, ti)) luaL_error(L, "field entry '%s': [2] must be the type", lua_tostring(L, ni));
		size_t nl;
		const char *ns = lua_tolstring(L, ni, &nl);
		uint32_t nc;
		int na;
		if (!split_array(ns, nl, nbuf, sizeof nbuf, &nc, &na) || na) luaL_error(L, "bad field name '%s'", ns);
		type = resolve_type(L, ti, sidx, &count, &is_array);
		if (!lua_isnil(L, ci))
		{
			if (is_array) luaL_error(L, "array count given twice for '%s'", nbuf);
			lua_Integer c = luaL_checkinteger(L, ci);
			if (c < 1 || c > 0xFFFFFF) luaL_error(L, "bad array count for '%s'", nbuf);
			count = (uint32_t)c;
			is_array = 1;
		}
	}
	else
	{
		luaL_error(L, "field entries must be strings (\"u8 name[4]\") or tables ({\"name\", \"type\" [, count]})");
		return;
	}

	if (strlen(nbuf) >= MG_NAME_MAX) luaL_error(L, "field name too long: %s", nbuf);
	for (int i = 0; i < nprev; i++)
		if (strcmp(prev[i].name, nbuf) == 0) luaL_error(L, "duplicate field '%s'", nbuf);
	strcpy(f->name, nbuf);
	f->type = type;
	f->count = count;
	f->is_array = is_array;
	lua_settop(L, base);
}

/* Builds a struct userdata from the definition table at idx and leaves it on top of the stack. */
static mg_struct *build_struct(lua_State *L, int def)
{
	def = lua_absindex(L, def);
	luaL_checktype(L, def, LUA_TTABLE);
	lua_Integer n = (lua_Integer)lua_rawlen(L, def);
	if (n < 1) luaL_error(L, "struct definition is empty");
	if (n > 1024) luaL_error(L, "struct has too many fields (max 1024)");

	mg_struct *s = (mg_struct *)lua_newuserdatauv(L, sizeof(mg_struct), 1);
	memset(s, 0, sizeof * s);
	luaL_setmetatable(L, STRUCT_MT);
	int sidx = lua_gettop(L);
	lua_newtable(L);
	lua_setiuservalue(L, sidx, 1);

	s->t.is_struct = 1;
	s->t.fields = (mg_field *)calloc((size_t)n, sizeof(mg_field));
	if (!s->t.fields) luaL_error(L, "out of memory");

	lua_getfield(L, def, "packed");
	int packed = lua_toboolean(L, -1);
	lua_pop(L, 1);

	uint64_t off = 0;
	uint32_t maxalign = 1;
	for (lua_Integer i = 1; i <= n; i++)
	{
		lua_rawgeti(L, def, i);
		int e = lua_gettop(L);
		mg_field *f = &s->t.fields[i - 1];
		parse_entry(L, e, sidx, f, s->t.fields, (int)(i - 1));
		uint32_t a = packed ? 1 : f->type->align;
		off = align_up(off, a);
		f->offset = (uint32_t)off;
		off += (uint64_t)f->type->size * f->count;
		if (off > MG_MAX_STRUCT) luaL_error(L, "struct too large");
		if (a > maxalign) maxalign = a;
		s->t.nfields = (int)i;
		lua_pop(L, 1);
	}
	s->t.align = maxalign;
	s->t.size = (uint32_t)align_up(off, maxalign);
	return s;
}

static int l_struct(lua_State *L)
{
	build_struct(L, 1);
	return 1;
}

/* sizeof("u16") / sizeof("u8[16]") / sizeof({...}) / sizeof(struct) -> size, align */
static int l_sizeof(lua_State *L)
{
	mg_struct *s = (mg_struct *)luaL_testudata(L, 1, STRUCT_MT);
	if (s)
	{
		lua_pushinteger(L, s->t.size);
		lua_pushinteger(L, s->t.align);
		return 2;
	}
	if (lua_type(L, 1) == LUA_TSTRING)
	{
		size_t n;
		const char *str = lua_tolstring(L, 1, &n);
		char base[64];
		uint32_t c;
		int arr;
		if (!split_array(str, n, base, sizeof base, &c, &arr)) return luaL_error(L, "bad type syntax '%s'", str);
		int p = find_prim(base, strlen(base));
		if (p < 0) return luaL_error(L, "unknown type '%s'", base);
		lua_pushinteger(L, (lua_Integer)PRIM_TYPES[p].size * c);
		lua_pushinteger(L, PRIM_TYPES[p].align);
		return 2;
	}
	s = build_struct(L, 1);
	lua_pushinteger(L, s->t.size);
	lua_pushinteger(L, s->t.align);
	return 2;
}

static int l_alignof(lua_State *L)
{
	l_sizeof(L);
	lua_pushvalue(L, -1);
	return 1;
}

/* find offset of "a.b.c" inside a struct type */
static void locate(lua_State *L, const mg_type *t, const char *path, size_t *off, const mg_field **ff)
{
	size_t o = 0;
	const mg_field *f;
	for (;;)
	{
		if (!t->is_struct) luaL_error(L, "'%s': not a struct", path);
		const char *dot = strchr(path, '.');
		size_t len = dot ? (size_t)(dot - path) : strlen(path);
		f = find_field(t, path, len);
		if (!f) luaL_error(L, "no field '%.*s'", (int)len, path);
		o += f->offset;
		if (!dot) break;
		if (f->is_array || !f->type->is_struct) luaL_error(L, "cannot index into field '%s'", f->name);
		t = f->type;
		path = dot + 1;
	}
	*off = o;
	*ff = f;
}

static mg_struct *check_struct(lua_State *L, int idx)
{
	return (mg_struct *)luaL_checkudata(L, idx, STRUCT_MT);
}

/* S:offsetof("path") -> offset, size_of_one_element, count */
static int st_offsetof(lua_State *L)
{
	mg_struct *s = check_struct(L, 1);
	size_t off;
	const mg_field *f;
	locate(L, &s->t, luaL_checkstring(L, 2), &off, &f);
	lua_pushinteger(L, (lua_Integer)off);
	lua_pushinteger(L, f->type->size);
	lua_pushinteger(L, f->count);
	return 3;
}

/* S:fields() -> { {name=, type=, offset=, size=, count=}, ... } */
static int st_fields(lua_State *L)
{
	mg_struct *s = check_struct(L, 1);
	lua_createtable(L, s->t.nfields, 0);
	for (int i = 0; i < s->t.nfields; i++)
	{
		const mg_field *f = &s->t.fields[i];
		lua_createtable(L, 0, 5);
		lua_pushstring(L, f->name);
		lua_setfield(L, -2, "name");
		lua_pushstring(L, f->type->is_struct ? "struct" : PRIM_NAMES[f->type->prim]);
		lua_setfield(L, -2, "type");
		lua_pushinteger(L, f->offset);
		lua_setfield(L, -2, "offset");
		lua_pushinteger(L, f->type->size);
		lua_setfield(L, -2, "size");
		lua_pushinteger(L, f->count);
		lua_setfield(L, -2, "count");
		lua_rawseti(L, -2, i + 1);
	}
	return 1;
}

static int st_tostring(lua_State *L)
{
	mg_struct *s = check_struct(L, 1);
	lua_pushfstring(L, "struct<size=%d, align=%d, fields=%d>", (int)s->t.size, (int)s->t.align, s->t.nfields);
	return 1;
}

static int st_index(lua_State *L);

/* ======================================================================= */
/*  views and records                                                      */
/* ======================================================================= */

typedef struct mg_view
{
	mg_mem *mem;
	const mg_type *type;
	size_t base;
	size_t count;
	int record; /* 1: single struct element accessed by field name */
} mg_view;

static mg_view *check_view(lua_State *L, int idx) { return (mg_view *)luaL_checkudata(L, idx, VIEW_MT); }

/* Creates a view userdata (slots not yet set). Pushes it. */
static mg_view *view_alloc(lua_State *L, mg_mem *m, const mg_type *t, size_t base, size_t count, int record)
{
	if (!m->data) luaL_error(L, "use of freed memory");
	if (t->size == 0) luaL_error(L, "zero-sized type");
	if (base > m->size || count > (m->size - base) / t->size)
		luaL_error(L, "view exceeds memory bounds (offset %I, count %I, element size %I, memory size %I)",
				   (lua_Integer)base, (lua_Integer)count, (lua_Integer)t->size, (lua_Integer)m->size);
	mg_view *v = (mg_view *)lua_newuserdatauv(L, sizeof(mg_view), 2);
	v->mem = m;
	v->type = t;
	v->base = base;
	v->count = count;
	v->record = record;
	luaL_setmetatable(L, VIEW_MT);
	return v;
}

/* copies anchors 1 and 2 from the view at `parent` to the userdata on top */
static void copy_anchors(lua_State *L, int parent)
{
	parent = lua_absindex(L, parent);
	int top = lua_gettop(L);
	lua_getiuservalue(L, parent, 1);
	lua_setiuservalue(L, top, 1);
	lua_getiuservalue(L, parent, 2);
	lua_setiuservalue(L, top, 2);
}

static const mg_type *arg_type(lua_State *L, int idx, int *anchor)
{
	*anchor = 0;
	if (lua_type(L, idx) == LUA_TSTRING)
	{
		size_t n;
		const char *s = lua_tolstring(L, idx, &n);
		int p = find_prim(s, n);
		if (p < 0) luaL_argerror(L, idx, lua_pushfstring(L, "unknown type '%s'", s));
		return &PRIM_TYPES[p];
	}
	mg_struct *st = (mg_struct *)luaL_testudata(L, idx, STRUCT_MT);
	if (!st) luaL_typeerror(L, idx, "type name or struct");
	*anchor = lua_absindex(L, idx);
	return &st->t;
}

static int view_impl(lua_State *L, int mi, int ti, int oi, int ci)
{
	mg_mem *m = mgold_checkmem(L, mi);
	int anchor;
	const mg_type *t = arg_type(L, ti, &anchor);
	size_t off = arg_off(L, oi, 0);
	if (off > m->size) luaL_argerror(L, oi, "offset out of bounds");
	size_t cnt;
	if (lua_isnoneornil(L, ci)) cnt = (m->size - off) / t->size;
	else cnt = arg_off(L, ci, 0);
	mi = lua_absindex(L, mi);
	view_alloc(L, m, t, off, cnt, 0);
	lua_pushvalue(L, mi);
	lua_setiuservalue(L, -2, 1);
	if (anchor)
	{
		lua_pushvalue(L, anchor);
		lua_setiuservalue(L, -2, 2);
	}
	return 1;
}

/* mem:view(type [, offset [, count]]) */
static int m_view(lua_State *L) { return view_impl(L, 1, 2, 3, 4); }
/* S:view(mem [, offset [, count]]) */
static int st_view(lua_State *L) { return view_impl(L, 2, 1, 3, 4); }

/* stdlib.new(type, count) / S:new(count): allocate + view */
static int new_impl(lua_State *L, int ti, int ci)
{
	int anchor;
	const mg_type *t = arg_type(L, ti, &anchor);
	lua_Integer cnt = luaL_optinteger(L, ci, 1);
	if (cnt < 1) luaL_argerror(L, ci, "count must be >= 1");
	if ((uint64_t)cnt > MG_MAX_ALLOC / t->size) luaL_error(L, "allocation too large");
	mg_mem *m = mgold_newmem(L, (size_t)cnt * t->size);
	int mi = lua_gettop(L);
	view_alloc(L, m, t, 0, (size_t)cnt, 0);
	lua_pushvalue(L, mi);
	lua_setiuservalue(L, -2, 1);
	if (anchor)
	{
		lua_pushvalue(L, anchor);
		lua_setiuservalue(L, -2, 2);
	}
	return 1;
}
static int l_new(lua_State *L) { return new_impl(L, 1, 2); }
static int st_new(lua_State *L) { return new_impl(L, 1, 2); }

static uint8_t *view_elem(lua_State *L, mg_view *v, lua_Integer i)
{
	if (!v->mem->data) luaL_error(L, "use of freed memory");
	if (i < 0 || (size_t)i >= v->count) luaL_error(L, "view index %I out of range (count %I)", i, (lua_Integer)v->count);
	size_t off = v->base + (size_t)i * v->type->size;
	if (off > v->mem->size || v->type->size > v->mem->size - off)
		luaL_error(L, "view exceeds memory bounds (was the memory resized?)");
	return v->mem->data + off;
}

/* ---- aggregate <-> Lua table ---- */
static void push_value(lua_State *L, const mg_type *t, const uint8_t *p);

static void push_field_value(lua_State *L, const mg_field *f, const uint8_t *p)
{
	if (f->is_array)
	{
		lua_createtable(L, (int)f->count, 0);
		for (uint32_t k = 0; k < f->count; k++)
		{
			push_value(L, f->type, p + (size_t)k * f->type->size);
			lua_rawseti(L, -2, (lua_Integer)k + 1);
		}
	}
	else
	{
		push_value(L, f->type, p);
	}
}

static void push_value(lua_State *L, const mg_type *t, const uint8_t *p)
{
	if (!t->is_struct)
	{
		push_prim(L, t->prim, p, 0);
		return;
	}
	luaL_checkstack(L, 4, "struct too deep");
	lua_createtable(L, 0, t->nfields);
	for (int i = 0; i < t->nfields; i++)
	{
		push_field_value(L, &t->fields[i], p + t->fields[i].offset);
		lua_setfield(L, -2, t->fields[i].name);
	}
}

static void assign_value(lua_State *L, const mg_type *t, uint8_t *p, int validx);

static void assign_field(lua_State *L, const mg_field *f, uint8_t *p, int validx)
{
	if (f->is_array)
	{
		luaL_checktype(L, validx, LUA_TTABLE);
		for (uint32_t k = 0; k < f->count; k++)
		{
			lua_rawgeti(L, validx, (lua_Integer)k + 1);
			if (!lua_isnil(L, -1)) assign_value(L, f->type, p + (size_t)k * f->type->size, lua_gettop(L));
			lua_pop(L, 1);
		}
	}
	else
	{
		assign_value(L, f->type, p, validx);
	}
}

static void assign_value(lua_State *L, const mg_type *t, uint8_t *p, int validx)
{
	if (!t->is_struct)
	{
		store_prim(L, t->prim, p, 0, validx);
		return;
	}
	luaL_checkstack(L, 4, "struct too deep");
	luaL_checktype(L, validx, LUA_TTABLE);
	for (int i = 0; i < t->nfields; i++)
	{
		lua_getfield(L, validx, t->fields[i].name);
		if (!lua_isnil(L, -1)) assign_field(L, &t->fields[i], p + t->fields[i].offset, lua_gettop(L));
		lua_pop(L, 1);
	}
}

/* Reads field f of the record view at stack index vi (a view userdata) */
static void read_field(lua_State *L, int vi, mg_view *v, const mg_field *f)
{
	vi = lua_absindex(L, vi);
	uint8_t *el = view_elem(L, v, 0);
	size_t fbase = v->base + f->offset;
	if (f->is_array)
	{
		view_alloc(L, v->mem, f->type, fbase, f->count, 0);
		copy_anchors(L, vi);
	}
	else if (f->type->is_struct)
	{
		view_alloc(L, v->mem, f->type, fbase, 1, 1);
		copy_anchors(L, vi);
	}
	else
	{
		push_prim(L, f->type->prim, el + f->offset, 0);
	}
}

static int view_index(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (lua_type(L, 2) == LUA_TNUMBER)
	{
		int ok;
		lua_Integer i = lua_tointegerx(L, 2, &ok);
		if (!ok) return luaL_error(L, "view index must be an integer");
		if (v->record) return luaL_error(L, "record: use field names, not indices");
		uint8_t *el = view_elem(L, v, i);
		if (!v->type->is_struct)
		{
			push_prim(L, v->type->prim, el, 0);
		}
		else
		{
			view_alloc(L, v->mem, v->type, v->base + (size_t)i * v->type->size, 1, 1);
			copy_anchors(L, 1);
		}
		return 1;
	}
	if (v->record && lua_type(L, 2) == LUA_TSTRING)
	{
		size_t n;
		const char *k = lua_tolstring(L, 2, &n);
		const mg_field *f = find_field(v->type, k, n);
		if (f)
		{
			read_field(L, 1, v, f);
			return 1;
		}
	}
	lua_pushvalue(L, 2);
	lua_rawget(L, lua_upvalueindex(1));
	return 1;
}

static int view_newindex(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (lua_type(L, 2) == LUA_TNUMBER)
	{
		int ok;
		lua_Integer i = lua_tointegerx(L, 2, &ok);
		if (!ok) return luaL_error(L, "view index must be an integer");
		if (v->record) return luaL_error(L, "record: use field names, not indices");
		uint8_t *el = view_elem(L, v, i);
		assign_value(L, v->type, el, 3);
		return 0;
	}
	if (v->record && lua_type(L, 2) == LUA_TSTRING)
	{
		size_t n;
		const char *k = lua_tolstring(L, 2, &n);
		const mg_field *f = find_field(v->type, k, n);
		if (!f) return luaL_error(L, "no field '%s'", k);
		uint8_t *el = view_elem(L, v, 0);
		assign_field(L, f, el + f->offset, 3);
		return 0;
	}
	return luaL_error(L, "cannot assign to view key");
}

static int view_len(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	lua_pushinteger(L, (lua_Integer)v->count);
	return 1;
}

static int view_tostring(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->record) lua_pushfstring(L, "record<struct size=%d>", (int)v->type->size);
	else if (v->type->is_struct) lua_pushfstring(L, "view<struct size=%d x%I>", (int)v->type->size, (lua_Integer)v->count);
	else lua_pushfstring(L, "view<%s x%I>", PRIM_NAMES[v->type->prim], (lua_Integer)v->count);
	return 1;
}

/* view:mem() -> underlying mem */
static int v_mem(lua_State *L)
{
	check_view(L, 1);
	lua_getiuservalue(L, 1, 1);
	return 1;
}
static int v_elemsize(lua_State *L)
{
	lua_pushinteger(L, check_view(L, 1)->type->size);
	return 1;
}
static int v_count(lua_State *L)
{
	lua_pushinteger(L, (lua_Integer)check_view(L, 1)->count);
	return 1;
}
static int v_offset(lua_State *L)
{
	lua_pushinteger(L, (lua_Integer)check_view(L, 1)->base);
	return 1;
}

/* view:slice(first, count) -> sub view (same memory) */
static int v_slice(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->record) return luaL_error(L, "cannot slice a record");
	size_t first = arg_off(L, 2, 0);
	size_t cnt = arg_off(L, 3, first <= v->count ? v->count - first : 0);
	if (first > v->count || cnt > v->count - first) return luaL_error(L, "slice out of range");
	view_alloc(L, v->mem, v->type, v->base + first * v->type->size, cnt, 0);
	copy_anchors(L, 1);
	return 1;
}

/* view:totable() -> 1-based Lua table of values (or of field tables); records give a field table */
static int v_totable(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->record)
	{
		push_value(L, v->type, view_elem(L, v, 0));
		return 1;
	}
	lua_createtable(L, (int)(v->count > 1 << 20 ? 1 << 20 : v->count), 0);
	for (size_t i = 0; i < v->count; i++)
	{
		push_value(L, v->type, view_elem(L, v, (lua_Integer)i));
		lua_rawseti(L, -2, (lua_Integer)i + 1);
	}
	return 1;
}

/* view:fromtable(t) (1-based Lua table) ; record:assign(t) */
static int v_fromtable(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	luaL_checktype(L, 2, LUA_TTABLE);
	if (v->record)
	{
		assign_value(L, v->type, view_elem(L, v, 0), 2);
		lua_settop(L, 1);
		return 1;
	}
	size_t n = lua_rawlen(L, 2);
	if (n > v->count) n = v->count;
	for (size_t i = 0; i < n; i++)
	{
		lua_rawgeti(L, 2, (lua_Integer)i + 1);
		assign_value(L, v->type, view_elem(L, v, (lua_Integer)i), lua_gettop(L));
		lua_pop(L, 1);
	}
	lua_settop(L, 1);
	return 1;
}

/* view:zero() */
static int v_zero(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->count == 0) return 0;
	uint8_t *p = view_elem(L, v, 0);
	view_elem(L, v, (lua_Integer)v->count - 1);
	memset(p, 0, v->count * v->type->size);
	lua_settop(L, 1);
	return 1;
}

/* view:get([i,] "a.b.c") / view:set([i,] "a.b.c", value) */
static int v_get(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (!v->type->is_struct) return luaL_error(L, "get(): elements are not structs");
	int pi = 2;
	lua_Integer i = 0;
	if (!v->record)
	{
		i = luaL_checkinteger(L, 2);
		pi = 3;
	}
	const char *path = luaL_checkstring(L, pi);
	uint8_t *el = view_elem(L, v, i);
	size_t off;
	const mg_field *f;
	locate(L, v->type, path, &off, &f);
	push_field_value(L, f, el + off);
	return 1;
}

static int v_set(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (!v->type->is_struct) return luaL_error(L, "set(): elements are not structs");
	int pi = 2;
	lua_Integer i = 0;
	if (!v->record)
	{
		i = luaL_checkinteger(L, 2);
		pi = 3;
	}
	const char *path = luaL_checkstring(L, pi);
	uint8_t *el = view_elem(L, v, i);
	size_t off;
	const mg_field *f;
	locate(L, v->type, path, &off, &f);
	luaL_checkany(L, pi + 1);
	assign_field(L, f, el + off, pi + 1);
	lua_settop(L, 1);
	return 1;
}

/* char arrays: view:str() / view:setstr(s) for 1-byte element views */
static int v_str(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->type->is_struct || v->type->size != 1) return luaL_error(L, "str(): view must be of 1-byte elements");
	if (v->count == 0)
	{
		lua_pushliteral(L, "");
		return 1;
	}
	const uint8_t *p = view_elem(L, v, 0);
	view_elem(L, v, (lua_Integer)v->count - 1);
	const uint8_t *z = (const uint8_t *)memchr(p, 0, v->count);
	lua_pushlstring(L, (const char *)p, z ? (size_t)(z - p) : v->count);
	return 1;
}

static int v_setstr(lua_State *L)
{
	mg_view *v = check_view(L, 1);
	if (v->type->is_struct || v->type->size != 1) return luaL_error(L, "setstr(): view must be of 1-byte elements");
	size_t n;
	const char *s = luaL_checklstring(L, 2, &n);
	if (v->count == 0)
	{
		lua_pushinteger(L, 0);
		return 1;
	}
	uint8_t *p = view_elem(L, v, 0);
	view_elem(L, v, (lua_Integer)v->count - 1);
	size_t w = n < v->count ? n : v->count;
	memcpy(p, s, w);
	if (w < v->count) memset(p + w, 0, v->count - w);
	lua_pushinteger(L, (lua_Integer)w);
	return 1;
}

static int st_index(lua_State *L)
{
	mg_struct *s = check_struct(L, 1);
	if (lua_type(L, 2) == LUA_TSTRING)
	{
		const char *k = lua_tostring(L, 2);
		if (strcmp(k, "size") == 0) { lua_pushinteger(L, s->t.size); return 1; }
		if (strcmp(k, "align") == 0) { lua_pushinteger(L, s->t.align); return 1; }
		if (strcmp(k, "nfields") == 0) { lua_pushinteger(L, s->t.nfields); return 1; }
	}
	lua_pushvalue(L, 2);
	lua_rawget(L, lua_upvalueindex(1));
	return 1;
}

/* ======================================================================= */
/*  Strings                                                                */
/* ======================================================================= */

static int s_split(lua_State *L)
{
	size_t sl, pl = 0;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *sep = luaL_optlstring(L, 2, NULL, &pl);
	lua_Integer max = luaL_optinteger(L, 3, 0);
	lua_newtable(L);
	lua_Integer n = 0;
	const char *end = s + sl;
	if (!sep)
	{
		const char *p = s;
		for (;;)
		{
			while (p < end && isspace((unsigned char)*p)) p++;
			if (p >= end) break;
			if (max > 0 && n == max - 1)
			{
				lua_pushlstring(L, p, (size_t)(end - p));
				lua_rawseti(L, -2, ++n);
				break;
			}
			const char *q = p;
			while (q < end && !isspace((unsigned char)*q)) q++;
			lua_pushlstring(L, p, (size_t)(q - p));
			lua_rawseti(L, -2, ++n);
			p = q;
		}
		return 1;
	}
	luaL_argcheck(L, pl > 0, 2, "empty separator");
	const char *p = s;
	for (;;)
	{
		const char *q = (max > 0 && n == max - 1) ? NULL : mem_find_bytes(p, (size_t)(end - p), sep, pl);
		if (!q)
		{
			lua_pushlstring(L, p, (size_t)(end - p));
			lua_rawseti(L, -2, ++n);
			break;
		}
		lua_pushlstring(L, p, (size_t)(q - p));
		lua_rawseti(L, -2, ++n);
		p = q + pl;
	}
	return 1;
}

static int s_lines(lua_State *L)
{
	size_t sl;
	const char *s = luaL_checklstring(L, 1, &sl);
	lua_newtable(L);
	lua_Integer n = 0;
	size_t i = 0, start = 0;
	while (i < sl)
	{
		if (s[i] == '\n' || s[i] == '\r')
		{
			lua_pushlstring(L, s + start, i - start);
			lua_rawseti(L, -2, ++n);
			if (s[i] == '\r' && i + 1 < sl && s[i + 1] == '\n') i++;
			start = i + 1;
		}
		i++;
	}
	if (start < sl)
	{
		lua_pushlstring(L, s + start, sl - start);
		lua_rawseti(L, -2, ++n);
	}
	return 1;
}

static int in_set(unsigned char c, const char *set, size_t sl)
{
	if (!set) return isspace(c) != 0;
	return memchr(set, c, sl) != NULL;
}

static int trim_impl(lua_State *L, int left, int right)
{
	size_t sl, cl = 0;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *set = luaL_optlstring(L, 2, NULL, &cl);
	size_t a = 0, b = sl;
	if (left) while (a < b && in_set((unsigned char)s[a], set, cl)) a++;
	if (right) while (b > a && in_set((unsigned char)s[b - 1], set, cl)) b--;
	lua_pushlstring(L, s + a, b - a);
	return 1;
}
static int s_trim(lua_State *L) { return trim_impl(L, 1, 1); }
static int s_ltrim(lua_State *L) { return trim_impl(L, 1, 0); }
static int s_rtrim(lua_State *L) { return trim_impl(L, 0, 1); }

static int s_startswith(lua_State *L)
{
	size_t sl, pl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *p = luaL_checklstring(L, 2, &pl);
	lua_pushboolean(L, pl <= sl && memcmp(s, p, pl) == 0);
	return 1;
}

static int s_endswith(lua_State *L)
{
	size_t sl, pl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *p = luaL_checklstring(L, 2, &pl);
	lua_pushboolean(L, pl <= sl && memcmp(s + sl - pl, p, pl) == 0);
	return 1;
}

static int s_contains(lua_State *L)
{
	size_t sl, pl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *p = luaL_checklstring(L, 2, &pl);
	lua_pushboolean(L, mem_find_bytes(s, sl, p, pl) != NULL);
	return 1;
}

static int s_count(lua_State *L)
{
	size_t sl, pl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *p = luaL_checklstring(L, 2, &pl);
	luaL_argcheck(L, pl > 0, 2, "empty pattern");
	lua_Integer n = 0;
	const char *end = s + sl;
	while ((s = mem_find_bytes(s, (size_t)(end - s), p, pl)) != NULL)
	{
		n++;
		s += pl;
	}
	lua_pushinteger(L, n);
	return 1;
}

/* replace(s, from, to [, max]) plain text */
static int s_replace(lua_State *L)
{
	size_t sl, fl, tl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *f = luaL_checklstring(L, 2, &fl);
	const char *t = luaL_checklstring(L, 3, &tl);
	lua_Integer max = luaL_optinteger(L, 4, 0);
	luaL_argcheck(L, fl > 0, 2, "empty pattern");
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	const char *end = s + sl;
	lua_Integer n = 0;
	while (s < end)
	{
		const char *q = (max > 0 && n >= max) ? NULL : mem_find_bytes(s, (size_t)(end - s), f, fl);
		if (!q) break;
		luaL_addlstring(&b, s, (size_t)(q - s));
		luaL_addlstring(&b, t, tl);
		s = q + fl;
		n++;
	}
	luaL_addlstring(&b, s, (size_t)(end - s));
	luaL_pushresult(&b);
	lua_pushinteger(L, n);
	return 2;
}

static int pad_impl(lua_State *L, int left)
{
	size_t sl, cl;
	const char *s = luaL_checklstring(L, 1, &sl);
	lua_Integer w = luaL_checkinteger(L, 2);
	const char *c = luaL_optlstring(L, 3, " ", &cl);

	luaL_argcheck(L, cl == 1, 3, "pad must be a single character");
	if (w < 0 || (size_t)w > MG_MAX_ALLOC)
		luaL_argerror(L, 2, "bad width");

	if ((size_t)w <= sl)
	{
		lua_settop(L, 1);
		return 1;
	}

	luaL_Buffer b;
	size_t pad = (size_t)w - sl;
	size_t i;

	luaL_buffinit(L, &b);

	if (left)
	{
		for (i = 0; i < pad; i++)
			luaL_addchar(&b, c[0]);
		luaL_addlstring(&b, s, sl);
	}
	else
	{
		luaL_addlstring(&b, s, sl);
		for (i = 0; i < pad; i++)
			luaL_addchar(&b, c[0]);
	}

	luaL_pushresult(&b);
	return 1;
}
static int s_padleft(lua_State *L) { return pad_impl(L, 1); }
static int s_padright(lua_State *L) { return pad_impl(L, 0); }

/* hex(s [, sep]) */
static int s_hex(lua_State *L)
{
	size_t sl, pl;
	const char *s = luaL_checklstring(L, 1, &sl);
	const char *sep = luaL_optlstring(L, 2, "", &pl);
	static const char H[] = "0123456789ABCDEF";
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	for (size_t i = 0; i < sl; i++)
	{
		if (i && pl) luaL_addlstring(&b, sep, pl);
		luaL_addchar(&b, H[(unsigned char)s[i] >> 4]);
		luaL_addchar(&b, H[(unsigned char)s[i] & 15]);
	}
	luaL_pushresult(&b);
	return 1;
}

static int hexval(int c)
{
	if (c >= '0' && c <= '9') return c - '0';
	if (c >= 'a' && c <= 'f') return c - 'a' + 10;
	if (c >= 'A' && c <= 'F') return c - 'A' + 10;
	return -1;
}

/* unhex("DE AD be ef") -> bytes ; whitespace, ',' and '$' are ignored */
static int s_unhex(lua_State *L)
{
	size_t sl;
	const char *s = luaL_checklstring(L, 1, &sl);
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	int hi = -1;
	for (size_t i = 0; i < sl; i++)
	{
		unsigned char c = (unsigned char)s[i];
		if (isspace(c) || c == ',' || c == '$') continue;
		int v = hexval(c);
		if (v < 0)
		{
			lua_pushnil(L);
			lua_pushfstring(L, "invalid hex digit at position %I", (lua_Integer)i + 1);
			return 2;
		}
		if (hi < 0) hi = v;
		else
		{
			luaL_addchar(&b, (char)(hi << 4 | v));
			hi = -1;
		}
	}
	if (hi >= 0)
	{
		lua_pushnil(L);
		lua_pushstring(L, "odd number of hex digits");
		return 2;
	}
	luaL_pushresult(&b);
	return 1;
}

static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

static int s_b64enc(lua_State *L)
{
	size_t sl;
	const unsigned char *s = (const unsigned char *)luaL_checklstring(L, 1, &sl);
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	size_t i = 0;
	for (; i + 2 < sl; i += 3)
	{
		uint32_t v = (uint32_t)s[i] << 16 | (uint32_t)s[i + 1] << 8 | s[i + 2];
		luaL_addchar(&b, B64[v >> 18]);
		luaL_addchar(&b, B64[(v >> 12) & 63]);
		luaL_addchar(&b, B64[(v >> 6) & 63]);
		luaL_addchar(&b, B64[v & 63]);
	}
	if (sl - i == 1)
	{
		uint32_t v = (uint32_t)s[i] << 16;
		luaL_addchar(&b, B64[v >> 18]);
		luaL_addchar(&b, B64[(v >> 12) & 63]);
		luaL_addstring(&b, "==");
	}
	else if (sl - i == 2)
	{
		uint32_t v = (uint32_t)s[i] << 16 | (uint32_t)s[i + 1] << 8;
		luaL_addchar(&b, B64[v >> 18]);
		luaL_addchar(&b, B64[(v >> 12) & 63]);
		luaL_addchar(&b, B64[(v >> 6) & 63]);
		luaL_addchar(&b, '=');
	}
	luaL_pushresult(&b);
	return 1;
}

static int s_b64dec(lua_State *L)
{
	size_t sl;
	const char *s = luaL_checklstring(L, 1, &sl);
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	uint32_t acc = 0;
	int bits = 0, pad = 0;
	for (size_t i = 0; i < sl; i++)
	{
		unsigned char c = (unsigned char)s[i];
		if (isspace(c)) continue;
		if (c == '=') { pad++; continue; }
		const char *p = strchr(B64, c);
		if (!p || c == 0 || pad)
		{
			lua_pushnil(L);
			lua_pushstring(L, "invalid base64");
			return 2;
		}
		acc = acc << 6 | (uint32_t)(p - B64);
		bits += 6;
		if (bits >= 8)
		{
			bits -= 8;
			luaL_addchar(&b, (char)((acc >> bits) & 0xFF));
		}
	}
	luaL_pushresult(&b);
	return 1;
}

static int s_crc32(lua_State *L)
{
	size_t sl;
	const char *s = luaL_checklstring(L, 1, &sl);
	lua_pushinteger(L, crc32_run((uint32_t)luaL_optinteger(L, 2, 0), (const uint8_t *)s, sl));
	return 1;
}

static int s_adler32(lua_State *L)
{
	size_t sl;
	const uint8_t *s = (const uint8_t *)luaL_checklstring(L, 1, &sl);
	uint32_t a = 1, b = 0;
	for (size_t i = 0; i < sl; i++)
	{
		a = (a + s[i]) % 65521u;
		b = (b + a) % 65521u;
	}
	lua_pushinteger(L, (lua_Integer)(b << 16 | a));
	return 1;
}

static int s_fnv1a(lua_State *L)
{
	size_t sl;
	const uint8_t *s = (const uint8_t *)luaL_checklstring(L, 1, &sl);
	uint32_t h = 2166136261u;
	for (size_t i = 0; i < sl; i++)
	{
		h ^= s[i];
		h *= 16777619u;
	}
	lua_pushinteger(L, h);
	return 1;
}

static int s_escape(lua_State *L)
{
	size_t sl;
	const unsigned char *s = (const unsigned char *)luaL_checklstring(L, 1, &sl);
	luaL_Buffer b;
	luaL_buffinit(L, &b);
	char tmp[8];
	for (size_t i = 0; i < sl; i++)
	{
		unsigned char c = s[i];
		switch (c)
		{
		case '\n': luaL_addstring(&b, "\\n"); break;
		case '\r': luaL_addstring(&b, "\\r"); break;
		case '\t': luaL_addstring(&b, "\\t"); break;
		case '\\': luaL_addstring(&b, "\\\\"); break;
		case '"': luaL_addstring(&b, "\\\""); break;
		default:
			if (c >= 32 && c < 127) luaL_addchar(&b, (char)c);
			else
			{
				snprintf(tmp, sizeof tmp, "\\x%02X", c);
				luaL_addstring(&b, tmp);
			}
		}
	}
	luaL_pushresult(&b);
	return 1;
}

static int s_fmtsize(lua_State *L)
{
	lua_Number n = luaL_checknumber(L, 1);
	static const char *U[] = { "B", "KB", "MB", "GB", "TB" };
	int u = 0;
	char tmp[48];

	while (n >= 1024.0 && u < 4)
	{
		n /= 1024.0;
		u++;
	}

	if (u == 0)
		lua_pushfstring(L, "%d B", (int)n);
	else
	{
		snprintf(tmp, sizeof tmp, "%.1f %s", n, U[u]);
		lua_pushstring(L, tmp);
	}

	return 1;
}
static int s_tohex(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer d = luaL_optinteger(L, 2, 0);
	const char *pre = luaL_optstring(L, 3, "$");
	if (d <= 0) d = n <= 0xFF ? 2 : n <= 0xFFFF ? 4 : n <= 0xFFFFFFFFu ? 8 : 16;
	if (d > 16) d = 16;
	char tmp[40];
	snprintf(tmp, sizeof tmp, "%0*llX", (int)d, (unsigned long long)n);
	lua_pushfstring(L, "%s%s", pre, tmp);
	return 1;
}

/* fromhex("$FF" | "0xFF" | "FF") -> integer | nil */
static int s_fromhex(lua_State *L)
{
	size_t sl;
	const char *s = luaL_checklstring(L, 1, &sl);
	while (sl && isspace((unsigned char)*s)) { s++; sl--; }
	while (sl && isspace((unsigned char)s[sl - 1])) sl--;
	if (sl && *s == '$') { s++; sl--; }
	else if (sl > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) { s += 2; sl -= 2; }
	if (sl == 0 || sl > 16) { lua_pushnil(L); return 1; }
	uint64_t v = 0;
	for (size_t i = 0; i < sl; i++)
	{
		int h = hexval((unsigned char)s[i]);
		if (h < 0) { lua_pushnil(L); return 1; }
		v = v << 4 | (uint64_t)h;
	}
	lua_pushinteger(L, (lua_Integer)v);
	return 1;
}

/* tobin(n [, bits=8 [, prefix="%"]]) */
static int s_tobin(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer bits = luaL_optinteger(L, 2, 8);
	const char *pre = luaL_optstring(L, 3, "%");
	luaL_argcheck(L, bits >= 1 && bits <= 64, 2, "bits must be 1..64");
	char tmp[72];
	for (lua_Integer i = 0; i < bits; i++) tmp[i] = ((n >> (bits - 1 - i)) & 1) ? '1' : '0';
	tmp[bits] = 0;
	lua_pushfstring(L, "%s%s", pre, tmp);
	return 1;
}

/* ======================================================================= */
/*  Bits                                                                   */
/* ======================================================================= */

static uint64_t bit_mask(lua_State *L, int idx, lua_Integer bits)
{
	if (bits < 1 || bits > 64) luaL_argerror(L, idx, "bits must be 1..64");
	return bits == 64 ? ~(uint64_t)0 : (((uint64_t)1 << bits) - 1);
}

static int b_rol(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer k = luaL_checkinteger(L, 2);
	lua_Integer bits = luaL_optinteger(L, 3, 32);
	uint64_t m = bit_mask(L, 3, bits);
	n &= m;
	k = ((k % bits) + bits) % bits;
	uint64_t r = k ? (((n << k) | (n >> (bits - k))) & m) : n;
	lua_pushinteger(L, (lua_Integer)r);
	return 1;
}

static int b_ror(lua_State *L)
{
	lua_Integer k = luaL_checkinteger(L, 2);
	lua_Integer bits = luaL_optinteger(L, 3, 32);
	lua_pushinteger(L, -k);
	lua_replace(L, 2);
	(void)bits;
	return b_rol(L);
}

static int b_bswap(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer bytes = luaL_optinteger(L, 2, 4);
	luaL_argcheck(L, bytes >= 1 && bytes <= 8, 2, "bytes must be 1..8");
	uint64_t r = 0;
	for (lua_Integer i = 0; i < bytes; i++) r = (r << 8) | ((n >> (8 * i)) & 0xFF);
	lua_pushinteger(L, (lua_Integer)r);
	return 1;
}

static int b_popcount(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	int c = 0;
	while (n)
	{
		n &= n - 1;
		c++;
	}
	lua_pushinteger(L, c);
	return 1;
}

static int b_extract(lua_State *L)
{ /* extract(n, pos, width=1) */
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer pos = luaL_checkinteger(L, 2), w = luaL_optinteger(L, 3, 1);
	luaL_argcheck(L, pos >= 0 && pos < 64, 2, "pos must be 0..63");
	uint64_t m = bit_mask(L, 3, w);
	lua_pushinteger(L, (lua_Integer)((n >> pos) & m));
	return 1;
}

static int b_insert(lua_State *L)
{ /* insert(n, pos, width, value) */
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer pos = luaL_checkinteger(L, 2), w = luaL_checkinteger(L, 3);
	uint64_t v = (uint64_t)luaL_checkinteger(L, 4);
	luaL_argcheck(L, pos >= 0 && pos < 64, 2, "pos must be 0..63");
	uint64_t m = bit_mask(L, 3, w);
	n = (n & ~(m << pos)) | ((v & m) << pos);
	lua_pushinteger(L, (lua_Integer)n);
	return 1;
}

static int b_test(lua_State *L)
{
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer pos = luaL_checkinteger(L, 2);
	luaL_argcheck(L, pos >= 0 && pos < 64, 2, "pos must be 0..63");
	lua_pushboolean(L, (n >> pos) & 1);
	return 1;
}

static int b_sext(lua_State *L)
{ /* sign extend from `bits` */
	uint64_t n = (uint64_t)luaL_checkinteger(L, 1);
	lua_Integer bits = luaL_checkinteger(L, 2);
	uint64_t m = bit_mask(L, 2, bits);
	n &= m;
	if (bits < 64 && (n >> (bits - 1)) & 1) n |= ~m;
	lua_pushinteger(L, (lua_Integer)n);
	return 1;
}

/* ======================================================================= */
/*  Registration                                                           */
/* ======================================================================= */

static const luaL_Reg mem_methods[] = {
	{ "free", m_free },{ "size", m_size },{ "ptr", m_ptr },{ "fill", m_fill },{ "copy", m_copy },
	{ "get", m_get },{ "set", m_set },{ "peek", m_peek },{ "poke", m_poke },{ "peek16", m_peek16 },
	{ "poke16", m_poke16 },{ "getstr", m_getstr },{ "setstr", m_setstr },{ "cstr", m_cstr },{ "find", m_find },
	{ "cmp", m_cmp },{ "resize", m_resize },{ "sub", m_sub },{ "hexdump", m_hexdump },
	{ "crc32", m_crc32 },{ "save", m_save },{ "view", m_view },{ NULL, NULL } };

static const luaL_Reg view_methods[] = {
	{ "mem", v_mem },{ "elemsize", v_elemsize },{ "count", v_count },{ "offset", v_offset },
	{ "slice", v_slice },{ "totable", v_totable },{ "fromtable", v_fromtable },{ "assign", v_fromtable },
	{ "zero", v_zero },{ "get", v_get },{ "set", v_set },{ "str", v_str },
	{ "setstr", v_setstr },{ NULL, NULL } };

static const luaL_Reg struct_methods[] = {
	{ "offsetof", st_offsetof },{ "fields", st_fields },{ "new", st_new },{ "view", st_view },{ NULL, NULL } };

static const luaL_Reg str_funcs[] = {
	{ "split", s_split },{ "lines", s_lines },{ "trim", s_trim },{ "ltrim", s_ltrim },
	{ "rtrim", s_rtrim },{ "startswith", s_startswith },{ "endswith", s_endswith },{ "contains", s_contains },
	{ "count", s_count },{ "replace", s_replace },{ "padleft", s_padleft },{ "padright", s_padright },
	{ "hex", s_hex },{ "unhex", s_unhex },{ "base64enc", s_b64enc },{ "base64dec", s_b64dec },
	{ "crc32", s_crc32 },{ "adler32", s_adler32 },{ "fnv1a", s_fnv1a },{ "escape", s_escape },
	{ "fmtsize", s_fmtsize },{ "tohex", s_tohex },{ "fromhex", s_fromhex },{ "tobin", s_tobin },
	{ NULL, NULL } };

static const luaL_Reg bit_funcs[] = { { "rol", b_rol },{ "ror", b_ror },{ "bswap", b_bswap },
									 { "popcount", b_popcount },{ "extract", b_extract },{ "insert", b_insert },
									 { "test", b_test },{ "sext", b_sext },{ NULL, NULL } };

static const luaL_Reg stdlib_funcs[] = {
	{ "malloc", l_malloc },{ "free", l_free },{ "new", l_new },{ "struct", l_struct },
	{ "sizeof", l_sizeof },{ "alignof", l_alignof },{ "tomem", l_tomem },{ "readfile", l_readfile },
	{ "memcpy", l_memcpy },{ "memset", l_memset },{ NULL, NULL } };

/* creates metatable `name` with __index closure over a methods table */
static void make_class(
	lua_State *L,
	const char *name,
	const luaL_Reg *methods,
	lua_CFunction index,
	lua_CFunction newindex,
	lua_CFunction tostr,
	lua_CFunction len,
	lua_CFunction gc
)
{
	luaL_newmetatable(L, name);

	lua_newtable(L);
	luaL_setfuncs(L, methods, 0);

	lua_pushcclosure(L, index, 1);
	lua_setfield(L, -2, "__index");

	if (newindex)
	{
		lua_pushcfunction(L, newindex);
		lua_setfield(L, -2, "__newindex");
	}

	if (tostr)
	{
		lua_pushcfunction(L, tostr);
		lua_setfield(L, -2, "__tostring");
	}

	if (len)
	{
		lua_pushcfunction(L, len);
		lua_setfield(L, -2, "__len");
	}

	if (gc)
	{
		lua_pushcfunction(L, gc);
		lua_setfield(L, -2, "__gc");
	}

	lua_pop(L, 1);
}

void MGOLD_setStdlibFunc(lua_State *L)
{
	crc_init();

	make_class(L, MG_MEM_MT, mem_methods,
		mem_index,
		mem_newindex,
		mem_tostring,
		mem_len,
		mem_gc
	);

	luaL_getmetatable(L, MG_MEM_MT);
	lua_pushcfunction(L, mem_gc);
	lua_setfield(L, -2, "__close");
	lua_pop(L, 1);

	make_class(L, VIEW_MT, view_methods,
		view_index,
		view_newindex,
		view_tostring,
		view_len,
		NULL
	);

	make_class(L, STRUCT_MT, struct_methods,
		st_index,
		NULL,
		st_tostring,
		NULL,
		struct_gc
	);

	lua_newtable(L);
	luaL_setfuncs(L, stdlib_funcs, 0);

	lua_newtable(L);
	luaL_setfuncs(L, str_funcs, 0);
	lua_setfield(L, -2, "str");

	lua_newtable(L);
	luaL_setfuncs(L, bit_funcs, 0);
	lua_setfield(L, -2, "bit");

	lua_setfield(L, -2, "stdlib");
}

} // namespace mgold
} // namespace love
