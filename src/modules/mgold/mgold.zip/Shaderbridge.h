#pragma once

// Escrita NATIVA de uniforms no shader do LOVE 12 (sem Lua, sem pilha, sem shader:send).
//
// O LOVE guarda o valor de cada uniform em UniformInfo::data (floats/ints). Aqui escrevemos
// direto nesse buffer e chamamos Shader::updateUniform(info, 1), que e exatamente o que o
// wrap_Shader.cpp (shader:send) faz no fim. Se o shader nao for o ativo, o proprio LOVE
// enfileira o update e aplica quando ele for ativado -- funciona em todos os backends.
//
// As UniformInfo* sao resolvidas UMA vez (ver MGOLD_defaultUniforms em Shader.cpp).
// Chame dentro de luax_catchexcept: updateUniform pode lancar love::Exception.

#include "common/runtime.h"
#include "modules/graphics/Shader.h"

namespace love
{
namespace mgold
{

namespace bridge
{

typedef graphics::Shader Shader;
typedef graphics::Shader::UniformInfo Uniform;

// float / vec2 / vec3 / vec4 (n valores; extras ignorados, faltantes mantem o valor anterior)
inline void setFloats(Shader *s, const Uniform *u, const double *v, int n){
	if (!s || !u || u->baseType != Shader::UNIFORM_FLOAT)
		return;
	int c = u->components < n ? u->components : n;
	for (int i = 0; i < c; i++)
		u->floats[i] = (float) v[i];
	s->updateUniform(u, 1);
}

// mat4 a partir de 16 doubles em ordem de LINHA (mesmo layout de Matrices.cpp / shader:send padrao).
// A memoria do GL e column-major, entao transpoe na escrita.
inline void setMat4RowMajor(Shader *s, const Uniform *u, const double *m){
	if (!s || !u || u->baseType != Shader::UNIFORM_MATRIX || u->matrix.columns != 4 || u->matrix.rows != 4)
		return;
	for (int row = 0; row < 4; row++)
		for (int col = 0; col < 4; col++)
			u->floats[col * 4 + row] = (float) m[row * 4 + col];
	s->updateUniform(u, 1);
}

inline void setBool(Shader *s, const Uniform *u, bool v){
	if (!s || !u || u->baseType != Shader::UNIFORM_BOOL)
		return;
	u->ints[0] = v ? 1 : 0;
	s->updateUniform(u, 1);
}

}

}
}
