#pragma once

#include "common/runtime.h"
#include "common/Module.h"

#include "modules/graphics/Graphics.h"
#include "modules/graphics/Shader.h"
#include "modules/graphics/wrap_Shader.h"
#include "filesystem/Filesystem.h"
#include "filesystem/wrap_Filesystem.h"

#include "modules/mgold/Shader.h"


namespace love
{
namespace mgold
{

void MGOLD_setRenderFunc(lua_State *L);

// Lua API (rotation angles are radians, applied X then Y then Z about each primitive's center):
//          render.rectangle(mode, x, y, z, width, height, radius?, cornerSegments?, rotationX?, rotationY?, rotationZ?)
//          render.circle(mode, x, y, z, radius, segments?, rotationX?, rotationY?, rotationZ?)
//          render.line(x1, y1, z1, x2, y2, z2, rotationX?, rotationY?, rotationZ?)

}
}